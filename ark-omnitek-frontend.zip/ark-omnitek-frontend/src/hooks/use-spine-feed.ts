"use client";

import * as React from "react";

/**
 * Live spine telemetry feed. Prefers the bus WebSocket (direct from the
 * browser, URL via NEXT_PUBLIC_SPINE_WS_URL); when it is unreachable —
 * different host, firewall, no server — it degrades to polling the gateway
 * every few seconds so the operator always has a live view. Source is
 * reported honestly ('ws' | 'poll' | 'off').
 */

export type SpineEvent = Record<string, unknown> & {
  event_id?: string;
  organ?: string;
  signal_type?: string;
  severity?: number;
  verified?: boolean;
  timestamp_utc?: string;
};

const MAX_EVENTS = 60;

export function useSpineFeed(pollMs = 4000) {
  const [events, setEvents] = React.useState<SpineEvent[]>([]);
  const [source, setSource] = React.useState<"ws" | "poll" | "off" | "connecting">("connecting");

  const wsUrl = process.env.NEXT_PUBLIC_SPINE_WS_URL || "ws://127.0.0.1:8080/ws/telemetry";

  React.useEffect(() => {
    let ws: WebSocket | null = null;
    let poll: ReturnType<typeof setInterval> | null = null;
    let cancelled = false;

    const startPolling = () => {
      if (poll || cancelled) return;
      setSource("poll");
      const pull = async () => {
        try {
          const res = await fetch("/api/gateway/spine/api/state", { cache: "no-store" });
          if (!res.ok) throw new Error(String(res.status));
          const data = await res.json();
          if (!cancelled) {
            const recent = (data?.recent_events ?? []) as SpineEvent[];
            setEvents(recent.slice(-MAX_EVENTS));
            setSource(recent.length ? "poll" : "poll");
          }
        } catch {
          if (!cancelled) setSource("off");
        }
      };
      pull();
      poll = setInterval(pull, pollMs);
    };

    try {
      ws = new WebSocket(wsUrl);
      const wsTimeout = setTimeout(() => {
        if (ws && ws.readyState !== WebSocket.OPEN) {
          try { ws.close(); } catch { /* ignore */ }
          startPolling();
        }
      }, 3500);
      ws.onopen = () => {
        clearTimeout(wsTimeout);
        if (!cancelled) setSource("ws");
      };
      ws.onmessage = (e) => {
        try {
          const msg = JSON.parse(e.data as string);
          if (msg?.type === "event" && msg.data) {
            setEvents((prev) => [...prev.slice(-(MAX_EVENTS - 1)), msg.data as SpineEvent]);
          }
        } catch {
          /* ignore malformed frames */
        }
      };
      ws.onerror = () => {
        clearTimeout(wsTimeout);
        startPolling();
      };
      ws.onclose = () => {
        clearTimeout(wsTimeout);
        startPolling();
      };
    } catch {
      startPolling();
    }

    return () => {
      cancelled = true;
      if (poll) clearInterval(poll);
      if (ws) {
        ws.onclose = null;
        ws.onerror = null;
        try { ws.close(); } catch { /* ignore */ }
      }
    };
  }, [wsUrl, pollMs]);

  return { events, source };
}
