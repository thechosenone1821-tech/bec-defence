"use client";

import { create } from "zustand";
import type { SeverityBand } from "@/lib/gateway";

/**
 * Cross-application session signals. MAYA and Message Guard publish their
 * latest verdicts here; VIGIL fuses them into one risk verdict. In-memory
 * only — verdicts belong to the current console session, never persisted.
 */
export type SessionVerdict = {
  app: "maya" | "message-guard";
  band: SeverityBand;
  verdict: string;
  at: number;
  raw: Record<string, unknown>;
};

type SignalsState = {
  voice: SessionVerdict | null;
  message: SessionVerdict | null;
  setVoice: (v: SessionVerdict | null) => void;
  setMessage: (v: SessionVerdict | null) => void;
};

export const useSessionSignals = create<SignalsState>()((set) => ({
  voice: null,
  message: null,
  setVoice: (voice) => set({ voice }),
  setMessage: (message) => set({ message }),
}));
