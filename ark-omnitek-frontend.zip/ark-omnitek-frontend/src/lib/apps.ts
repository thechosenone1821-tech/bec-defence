import type { LucideIcon } from "lucide-react";
import {
  AudioLines,
  Radar,
  Landmark,
  MessageSquareLock,
  Orbit,
  Swords,
  Scale,
} from "lucide-react";

/**
 * ARK OMNITEK — subapplication registry.
 *
 * Two primary modes, seven subapplications. Every entry is a real destination
 * backed by the platform gateway (see src/app/api/gateway/*) — no placeholders.
 */

export type AppMode = "consumer" | "organization";

export type SubApp = {
  id: string;
  /** display name, exactly as specified by the product */
  name: string;
  /** mono kicker shown above the name */
  kicker: string;
  /** one-line caption under the name on the carousel card */
  caption: string;
  /** longer description used on the app pages */
  description: string;
  mode: AppMode;
  route: string;
  icon: LucideIcon;
  /** capability chips rendered on the card */
  capabilities: string[];
};

export const MODES: Record<
  AppMode,
  { label: string; blurb: string }
> = {
  consumer: {
    label: "Consumer",
    blurb: "Personal defence applications for citizens on the network edge.",
  },
  organization: {
    label: "Organization",
    blurb: "Ring-level defence, red-team replay and deterministic governance.",
  },
};

export const SUBAPPS: SubApp[] = [
  {
    id: "maya",
    name: "MAYA",
    kicker: "CONSUMER · 01",
    caption: "Voice-clone screen for suspicious calls.",
    description:
      "MAYA screens call audio for synthetic-speech red flags in a rolling three-second window. Audio is captured on-device, held in a ring buffer that is zeroed when you stop, and never stored. Verdicts are advisory and always end with a human next step.",
    mode: "consumer",
    route: "/console/maya",
    icon: AudioLines,
    capabilities: ["3s ring buffer", "Consent-gated", "Spectral screen", "Zero retention"],
  },
  {
    id: "vigil",
    name: "VIGIL",
    kicker: "CONSUMER · 02",
    caption: "Fused risk verdict from every citizen signal.",
    description:
      "VIGIL fuses independent signals — voice verdicts, message verdicts, campaign linkage, repeat contacts and your own doubt — into one bounded, inspectable risk verdict with plain-language reasons. It can say \"I don't know\": no signal is a LOW_CONFIDENCE band, never a reassuring \"safe\".",
    mode: "consumer",
    route: "/console/vigil",
    icon: Radar,
    capabilities: ["Noisy-OR fusion", "Plain-language reasons", "LOW_CONFIDENCE honest band"],
  },
  {
    id: "citizen-spine",
    name: "Citizen Spine",
    kicker: "CONSUMER · 03",
    caption: "One-tap signed reports into the shared spine.",
    description:
      "Citizen Spine is the report rail that files signed, tokenized incident reports into the shared defence spine — category and severity band only, never raw content — where they fuse with infrastructure evidence into a single campaign view.",
    mode: "consumer",
    route: "/console/citizen-spine",
    icon: Landmark,
    capabilities: ["HMAC-signed events", "No PII", "Campaign fusion", "1930 linkage"],
  },
  {
    id: "message-guard",
    name: "Message Guard",
    kicker: "CONSUMER · 04",
    caption: "Scam-script screen for SMS and chat text.",
    description:
      "Message Guard scores suspicious messages against known scam-script families across English, Hindi and Telugu. Every verdict ships with an explanation and the 1930 helpline — and honest LOW_CONFIDENCE when there is too little text to judge.",
    mode: "consumer",
    route: "/console/message-guard",
    icon: MessageSquareLock,
    capabilities: ["en / hi / te", "Scam families", "Explanations", "Advisory only"],
  },
  {
    id: "rings",
    name: "Rings",
    kicker: "ORGANIZATION · 01",
    caption: "Organ liveness across the four defence rings.",
    description:
      "Rings is the fleet console for the four paired defence rings — perimeter & identity, AI & agent defence, endpoint & silicon, network fabric & self-healing. Watch organ liveness, run positive-control canaries, and use operator kill switches with Governor-approved tokens.",
    mode: "organization",
    route: "/console/rings",
    icon: Orbit,
    capabilities: ["8 organs · 4 rings", "Liveness states", "Canary sweep", "Halt / resume"],
  },
  {
    id: "red-team",
    name: "Red Team",
    kicker: "ORGANIZATION · 02",
    caption: "Sandbox-only multi-stage campaign replay.",
    description:
      "Red Team replays the canonical multi-stage attack campaign — voice-clone vishing through document injection to ransomware — as signed organ telemetry through the same verification path real sensors use. A forged probe is submitted first to prove the bus holds unsigned evidence out of the AI path.",
    mode: "organization",
    route: "/console/red-team",
    icon: Swords,
    capabilities: ["Signed replay", "Forge probe first", "Campaign fusion", "Sandbox only"],
  },
  {
    id: "governance",
    name: "Governance",
    kicker: "ORGANIZATION · 03",
    caption: "Deterministic Governor, planner and ledger.",
    description:
      "Governance is the zero-AI policy plane: propose a minimum-disruption containment cut, watch the deterministic Governor approve or refuse it against budgets and Tier-0 locks, and read the hash-chained evidence ledger that seals every decision.",
    mode: "organization",
    route: "/console/governance",
    icon: Scale,
    capabilities: ["Blast-radius budgets", "Tier-0 locks", "Containment planner", "Hash-chained ledger"],
  },
];

export function appsForMode(mode: AppMode): SubApp[] {
  return SUBAPPS.filter((a) => a.mode === mode);
}

export function defaultAppForMode(mode: AppMode): SubApp {
  return appsForMode(mode)[0];
}

export function findApp(id: string): SubApp | undefined {
  return SUBAPPS.find((a) => a.id === id);
}
