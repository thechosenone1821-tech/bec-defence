"use client";

import * as React from "react";
import { Orbit, RefreshCw } from "lucide-react";
import {
  Kicker,
  PhosphorPanel,
  PhosphorButton,
  BackendNotice,
  StatTile,
} from "@/components/phosphor/primitives";
import { spine } from "@/lib/gateway";
import { useSpineFeed, type SpineEvent } from "@/hooks/use-spine-feed";

type OrganHealth = {
  state: string;
  ring?: string;
  calls?: number;
  errors?: number;
  emitted?: number;
  last_seen_age_sec?: number;
  last_error?: string | null;
};

type FleetSnapshot = {
  available: boolean;
  reason?: string;
  executor_mode?: string;
  organs?: Record<string, OrganHealth>;
  counts?: Record<string, number>;
  total?: number;
  all_healthy?: boolean;
  halted?: string[];
  silent?: string[];
  unobserved?: string[];
  canary?: {
    available?: boolean;
    reason?: string;
    results?: Record<string, { verdict?: string; detail?: string }>;
  };
};

type SpineState = {
  buffered_events?: number;
  executor_mode?: string;
  entity_graph?: { node_count?: number; edge_count?: number; window_sec?: number };
  campaigns?: { campaign_id?: string; size?: number; severity_max?: number }[];
  fortress?: { telemetry_mac?: boolean; unverified_held?: number; replay_dropped?: number };
  recent_events?: SpineEvent[];
};

const RING_LABELS: Record<string, string> = {
  RING_1_PERIMETER_IDENTITY: "Ring 1 · Perimeter & Identity",
  RING_2_AI_DEFENSE: "Ring 2 · Corporate AI & Agent Defence",
  RING_3_ENDPOINT_SILICON: "Ring 3 · Endpoint, Kernel & Silicon",
  RING_4_NETWORK_HEALING: "Ring 4 · Network Fabric & Self-Healing",
};

function stateColor(state: string): string {
  switch (state) {
    case "HEALTHY":
      return "var(--sev-mild)";
    case "DEGRADED":
    case "SILENT":
      return "var(--sev-moderate)";
    case "FAILING":
      return "var(--sev-critical)";
    case "HALTED":
      return "var(--muted-foreground)";
    default:
      return "var(--muted-foreground)";
  }
}

export function RingsApp() {
  const [fleet, setFleet] = React.useState<FleetSnapshot | null>(null);
  const [state, setState] = React.useState<SpineState | null>(null);
  const [error, setError] = React.useState<string | null>(null);
  const [busy, setBusy] = React.useState(false);
  const [canary, setCanary] = React.useState<FleetSnapshot["canary"] | null>(null);
  const [haltOrgan, setHaltOrgan] = React.useState("");
  const [haltReason, setHaltReason] = React.useState("");
  const [approval, setApproval] = React.useState("");
  const [opResult, setOpResult] = React.useState<string | null>(null);
  const { events, source } = useSpineFeed();

  const refresh = React.useCallback(async () => {
    setBusy(true);
    setError(null);
    const [f, s] = await Promise.all([
      spine<FleetSnapshot>("/api/fleet"),
      spine<SpineState>("/api/state"),
    ]);
    if (!f.ok && !s.ok) setError(f.error || s.error || "spine unreachable");
    if (f.ok) setFleet(f.data);
    if (s.ok) setState(s.data);
    setBusy(false);
  }, []);

  React.useEffect(() => {
    refresh();
    const t = setInterval(refresh, 20000);
    return () => clearInterval(t);
  }, [refresh]);

  const runCanary = async () => {
    const res = await spine<FleetSnapshot>("/api/fleet/canary");
    if (res.ok) setCanary(res.data.canary ?? null);
  };

  const fleetOp = async (kind: "halt" | "resume") => {
    if (!haltOrgan) return;
    const body: Record<string, unknown> = { reason: haltReason };
    if (approval.trim()) body.approval = JSON.parse(approval);
    const res = await spine<{ status?: string; reason?: string }>(
      `/api/fleet/${encodeURIComponent(haltOrgan)}/${kind}`,
      { method: "POST", body: JSON.stringify(body) },
    );
    setOpResult(
      res.ok
        ? `${res.data.status}: ${res.data.reason ?? "done"}`
        : `${res.status === 403 ? "GOVERNOR REFUSED" : "ERROR"}: ${res.error}`,
    );
    refresh();
  };

  const organs = fleet?.organs ?? {};
  const byRing: Record<string, [string, OrganHealth][]> = {};
  for (const [name, h] of Object.entries(organs)) {
    const ring = h.ring ?? "RING_UNSET";
    (byRing[ring] ??= []).push([name, h]);
  }

  return (
    <div className="space-y-6">
      {/* summary */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <StatTile
          label="fleet"
          value={fleet?.available === false ? "DRY-RUN" : `${fleet?.total ?? 0} organs`}
          hint={
            fleet?.available === false
              ? fleet.reason
              : `${fleet?.counts?.HEALTHY ?? 0} healthy · ${fleet?.silent?.length ?? 0} silent · ${fleet?.halted?.length ?? 0} halted`
          }
        />
        <StatTile
          label="graph window"
          value={`${state?.entity_graph?.node_count ?? 0}n / ${state?.entity_graph?.edge_count ?? 0}e`}
          hint={`${state?.entity_graph?.window_sec ?? 600}s sliding window · ${state?.buffered_events ?? 0} buffered`}
        />
        <StatTile
          label="fused campaigns"
          value={state?.campaigns?.length ?? 0}
          hint={state?.campaigns?.[0] ? `largest ${state.campaigns[0].campaign_id}` : "none in window"}
        />
        <StatTile
          label="quarantine"
          value={`${state?.fortress?.unverified_held ?? 0}/${state?.fortress?.replay_dropped ?? 0}`}
          hint="unverified held / replay dropped — forge attempts never pass"
        />
      </div>

      {/* rings */}
      {fleet && fleet.available && Object.keys(organs).length ? (
        <div className="grid gap-6 lg:grid-cols-2">
          {Object.entries(byRing).map(([ring, list]) => (
            <PhosphorPanel key={ring} className="p-6">
              <Kicker phosphor>{RING_LABELS[ring] ?? ring}</Kicker>
              <ul className="mt-4 space-y-2">
                {list.map(([name, h]) => (
                  <li
                    key={name}
                    className="flex items-center justify-between gap-3 rounded-md border border-border bg-secondary/50 px-4 py-3"
                    style={{ borderLeft: `3px solid ${stateColor(h.state)}` }}
                  >
                    <div className="min-w-0">
                      <p className="truncate font-mono text-sm text-foreground">{name}</p>
                      <p className="font-mono text-[11px] text-muted-foreground">
                        calls {h.calls ?? 0} · errors {h.errors ?? 0} · emitted {h.emitted ?? 0}
                      </p>
                    </div>
                    <span
                      className="shrink-0 rounded-full border px-2.5 py-0.5 font-mono text-[10px] tracking-[0.14em]"
                      style={{ color: stateColor(h.state), borderColor: stateColor(h.state) }}
                    >
                      {h.state}
                    </span>
                  </li>
                ))}
              </ul>
            </PhosphorPanel>
          ))}
        </div>
      ) : (
        <PhosphorPanel className="p-6">
          <Kicker phosphor>ORGAN FLEET</Kicker>
          <p className="mt-3 text-sm text-muted-foreground">
            {fleet?.available === false
              ? fleet.reason
              : "Fleet snapshot not available yet — the bus may be starting up."}
          </p>
        </PhosphorPanel>
      )}

      <div className="grid gap-6 lg:grid-cols-2">
        {/* operator controls */}
        <PhosphorPanel className="p-6">
          <Kicker phosphor>OPERATOR KILL SWITCH</Kicker>
          <p className="mt-2 text-sm text-muted-foreground">
            Halt or resume one organ. The AI path cannot do this — it requires a
            human approval token minted with the Governor key; without one the
            endpoint refuses with the Governor's verdict shown.
          </p>
          <div className="mt-4 grid gap-3">
            <select
              value={haltOrgan}
              onChange={(e) => setHaltOrgan(e.target.value)}
              className="h-11 rounded-md border border-input bg-secondary/70 px-3 font-mono text-sm text-foreground focus-visible:outline-2 focus-visible:outline-ring"
              aria-label="Organ"
            >
              <option value="">Select organ…</option>
              {Object.keys(organs).map((n) => (
                <option key={n} value={n}>
                  {n}
                </option>
              ))}
            </select>
            <input
              value={haltReason}
              onChange={(e) => setHaltReason(e.target.value)}
              placeholder="Reason (shown in the ledger)"
              className="h-11 rounded-md border border-input bg-secondary/70 px-3 text-sm text-foreground placeholder:text-muted-foreground/60 focus-visible:outline-2 focus-visible:outline-ring"
              aria-label="Reason"
            />
            <input
              value={approval}
              onChange={(e) => setApproval(e.target.value)}
              placeholder='Approval token JSON (optional — {"alg":…})'
              className="h-11 rounded-md border border-input bg-secondary/70 px-3 font-mono text-xs text-foreground placeholder:text-muted-foreground/60 focus-visible:outline-2 focus-visible:outline-ring"
              aria-label="Governor approval token"
            />
            <div className="flex flex-wrap gap-3">
              <PhosphorButton variant="danger" disabled={!haltOrgan} onClick={() => fleetOp("halt")}>
                Halt organ
              </PhosphorButton>
              <PhosphorButton variant="ghost" disabled={!haltOrgan} onClick={() => fleetOp("resume")}>
                Resume organ
              </PhosphorButton>
              <PhosphorButton variant="ghost" onClick={runCanary}>
                Run canary sweep
              </PhosphorButton>
            </div>
            {opResult ? (
              <p className="break-words rounded-md border border-border bg-secondary/50 p-3 font-mono text-xs text-muted-foreground">
                {opResult}
              </p>
            ) : null}
            {canary ? (
              <p className="font-mono text-xs text-muted-foreground">
                canary: {canary.available === false ? canary.reason ?? "unavailable" : JSON.stringify(canary.results ?? {}).slice(0, 220)}
              </p>
            ) : null}
          </div>
        </PhosphorPanel>

        {/* live feed */}
        <PhosphorPanel className="p-6">
          <div className="flex items-center justify-between">
            <Kicker phosphor>LIVE TELEMETRY</Kicker>
            <span className="font-mono text-[10px] uppercase tracking-[0.18em] text-muted-foreground">
              {source === "ws" ? "websocket" : source === "poll" ? "polling" : source}
            </span>
          </div>
          <div className="mt-4 max-h-72 space-y-1.5 overflow-y-auto ph-scroller" aria-live="polite">
            {events.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No events in the window yet. Run the Red Team replay or wait for organ traffic.
              </p>
            ) : (
              events.slice().reverse().map((e, i) => (
                <div
                  key={e.event_id ?? i}
                  className="flex items-center justify-between gap-3 rounded border border-border/60 bg-secondary/40 px-3 py-1.5 font-mono text-[11px]"
                >
                  <span className="truncate text-foreground/85">
                    {e.organ ?? "?"} · {e.signal_type ?? "?"}
                  </span>
                  <span className={e.verified ? "text-phosphor" : "text-sev-moderate"}>
                    {e.verified ? "✓" : "held"} sev {typeof e.severity === "number" ? e.severity.toFixed(2) : "?"}
                  </span>
                </div>
              ))
            )}
          </div>
          <div className="mt-4 flex items-center gap-2">
            <PhosphorButton variant="ghost" onClick={refresh} disabled={busy}>
              <RefreshCw className={busy ? "size-4 animate-spin" : "size-4"} aria-hidden="true" />
              Refresh snapshot
            </PhosphorButton>
          </div>
        </PhosphorPanel>
      </div>

      {error ? <BackendNotice detail={error} onRetry={refresh} /> : null}
    </div>
  );
}
