"use client";

import * as React from "react";
import { Swords, ShieldCheck, ShieldX, Play } from "lucide-react";
import {
  Kicker,
  PhosphorPanel,
  PhosphorButton,
  BackendNotice,
  StatTile,
} from "@/components/phosphor/primitives";
import { spine, spineSigned } from "@/lib/gateway";
import type { SpineEvent } from "@/hooks/use-spine-feed";

/**
 * Red Team — sandbox-only campaign replay.
 *
 * Mirrors the backend kill-chain player exactly: the canonical multi-stage
 * campaign (voice-clone vishing → invoice injection → cookie replay →
 * ransomware → power residual) is minted as signed organ telemetry through
 * the same verification path real sensors use. A forged, unsigned probe is
 * submitted FIRST and the AI path must hold — that refusal is the point.
 */

type CampaignStep = {
  name: string;
  ring: string;
  organ: string;
  signal_type: string;
  severity: number;
  entities: Record<string, string>;
  metrics: Record<string, number>;
  expect: string;
};

const CASE_ID = "CASE_RAAVAN_1930_0001";

const STEPS: CampaignStep[] = [
  {
    name: "T01 · voice-clone vishing (citizen leg)",
    ring: "RING_0_CITIZEN",
    organ: "CITIZEN_APP",
    signal_type: "CITIZEN_REPORT_VOICE",
    severity: 0.9,
    entities: { case_id: CASE_ID, agent_id: "CITIZEN_ANON" },
    metrics: { reports_day: 1 },
    expect: "citizen signal lands; verified; campaign seed",
  },
  {
    name: "T03 · poisoned vendor invoice (agent leg)",
    ring: "RING_2_AI_DEFENSE",
    organ: "BRAGG_FFT_FIREWALL",
    signal_type: "INDIRECT_INJECTION_BLOCKED",
    severity: 0.87,
    entities: { case_id: CASE_ID, doc_hash: "sha256:mockinv0123", agent_id: "AGENT_075AB2", host_id: "HOST_AB12CD" },
    metrics: { f2_norm_ratio: 0.81 },
    expect: "document quarantined proposal; injection blocked",
  },
  {
    name: "T04 · stolen session replay (identity leg)",
    ring: "RING_1_PERIMETER_IDENTITY",
    organ: "COOKIE_FLUID_TURBULENCE",
    signal_type: "TURBULENT_SESSION_REPLAY",
    severity: 0.85,
    entities: { case_id: CASE_ID, session_id: "SESS_9A8B7C", user_id: "USER_D15E55", host_id: "HOST_AB12CD" },
    metrics: { laminar_ratio: 0.11 },
    expect: "session revoked proposal; trap pre-arm",
  },
  {
    name: "T05 · ransomware parity collapse (endpoint leg)",
    ring: "RING_3_ENDPOINT_SILICON",
    organ: "ENDPOINT_PAGE_CURVE",
    signal_type: "PARITY_ENTROPY_COLLAPSE",
    severity: 0.96,
    entities: { case_id: CASE_ID, host_id: "HOST_AB12CD", user_id: "USER_D15E55", vlan_id: "VLAN_CORP_IT" },
    metrics: { bytes_written: 4096, parity_delta: 0.99 },
    expect: "PID termination + human step-up escalation",
  },
  {
    name: "T08 · unattributed power residual (endpoint leg)",
    ring: "RING_3_ENDPOINT_SILICON",
    organ: "LANDAUER_THERMAL_AUDIT",
    signal_type: "UNACCOUNTED_POWER_RESIDUAL",
    severity: 0.73,
    entities: { case_id: CASE_ID, host_id: "HOST_AB12CD", user_id: "USER_D15E55", vlan_id: "VLAN_CORP_IT" },
    metrics: { unaccounted_watts: 17.4 },
    expect: "host isolation proposal (dry-run)",
  },
];

function buildCampaign(): Record<string, unknown>[] {
  // event ids derive from the case id the same way the player does —
  // deterministic, unique per run window (replays within 10 min are dropped
  // by the bus, which is itself part of the demonstration)
  const nonce = Math.random().toString(16).slice(2, 8);
  const now = new Date().toISOString().replace(/\.\d+Z$/, "Z");
  return STEPS.map((s, i) => ({
    event_id: `evt_rt_${nonce}_${String(i + 1).padStart(4, "0")}`,
    timestamp_utc: now,
    ring: s.ring,
    organ: s.organ,
    signal_type: s.signal_type,
    severity: s.severity,
    entities: s.entities,
    metrics: s.metrics,
  }));
}

type OrchestrateBundle = {
  status?: string;
  reason?: string;
  commander_mode?: string;
  brief?: string;
  plan_id?: string;
  actions?: { tool?: string; args?: Record<string, unknown> }[];
  decisions?: { decision?: string; reason?: string; tool?: string }[];
  results?: { tool?: string; result?: Record<string, unknown> }[];
  unverified_events?: number;
};

type SpineState = {
  campaigns?: { campaign_id?: string; size?: number; severity_max?: number; entities?: string[] }[];
  fortress?: { unverified_held?: number; replay_dropped?: number };
  recent_events?: SpineEvent[];
};

type LogLine = { kind: "forge" | "hold" | "signed" | "plan" | "state" | "error"; text: string };

export function RedTeamApp() {
  const [running, setRunning] = React.useState(false);
  const [log, setLog] = React.useState<LogLine[]>([]);
  const [state, setState] = React.useState<SpineState | null>(null);
  const [error, setError] = React.useState<string | null>(null);

  const refreshState = React.useCallback(async () => {
    const res = await spine<SpineState>("/api/state");
    if (res.ok) setState(res.data);
    else setError(res.error);
  }, []);

  React.useEffect(() => {
    refreshState();
  }, [refreshState]);

  const push = (line: LogLine) => setLog((prev) => [...prev, line]);

  const runReplay = async () => {
    setRunning(true);
    setLog([]);
    setError(null);
    try {
      const unsigned = buildCampaign();

      // ACT 1 — forge: unsigned probe must be held
      push({ kind: "forge", text: "Submitting forged (unsigned) probe…" });
      const forge = await spine<{ accepted?: number; unverified?: number; received?: number }>(
        "/api/ingest",
        { method: "POST", body: JSON.stringify(unsigned) },
      );
      push(
        forge.ok
          ? { kind: "forge", text: `forged ingest → accepted ${forge.data.accepted}, unverified ${forge.data.unverified}` }
          : { kind: "error", text: forge.error },
      );

      // ACT 2 — the AI path must refuse to act on unverified evidence
      const held = await spine<OrchestrateBundle>("/api/orchestrate", { method: "POST", body: "{}" });
      push(
        held.ok
          ? {
              kind: "hold",
              text: `orchestrate → ${held.data.status}${held.data.reason ? ` (${held.data.reason})` : ""}`,
            }
          : { kind: "error", text: held.error },
      );
      if (held.ok && held.data.status !== "HELD_UNVERIFIED_EVIDENCE" && held.data.status !== "NO_EVENTS") {
        push({ kind: "error", text: "forged telemetry steered the AI path — FAIL" });
        setRunning(false);
        return;
      }

      // ACT 3 — the signed campaign, through the normal verification path
      push({ kind: "signed", text: "Minting signed campaign (HMAC-SHA256) and ingesting…" });
      const ack = await spineSigned(unsigned);
      push(
        ack.ok
          ? { kind: "signed", text: `signed ingest → accepted ${ack.data.accepted}, unverified ${ack.data.unverified}` }
          : { kind: "error", text: ack.error },
      );

      // ACT 4 — orchestrate on verified evidence
      const bundle = await spine<OrchestrateBundle>("/api/orchestrate", { method: "POST", body: "{}" });
      if (bundle.ok) {
        push({ kind: "plan", text: `orchestrate → ${bundle.data.status} · commander=${bundle.data.commander_mode ?? "?"}` });
        for (const d of bundle.data.decisions ?? []) {
          push({
            kind: "plan",
            text: `  ${d.tool ?? "tool"} → ${d.decision}${d.reason ? ` (${d.reason})` : ""}`,
          });
        }
        if (bundle.data.brief) push({ kind: "plan", text: `brief: ${bundle.data.brief}` });
      } else {
        push({ kind: "error", text: bundle.error });
      }

      // ACT 5 — fused campaign view
      await refreshState();
    } finally {
      setRunning(false);
    }
  };

  const top = state?.campaigns?.[0];

  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_400px]">
      {/* campaign */}
      <PhosphorPanel className="p-6" glow>
        <Kicker phosphor>CAMPAIGN REPLAY · SANDBOX ONLY</Kicker>
        <h2 className="mt-2 flex items-center gap-2 text-xl font-semibold">
          <Swords className="size-5 text-phosphor" aria-hidden="true" />
          Canonical multi-stage attack
        </h2>
        <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
          Five techniques across four layers, all sharing one opaque case token so
          the bus fuses them into a single campaign. Every event is signed at
          birth and verified by the bus like real organ telemetry — nothing
          bypasses the pipeline. Never pointed at any system you do not own.
        </p>

        <ol className="mt-6 space-y-2">
          {STEPS.map((s, i) => (
            <li
              key={s.name}
              className="rounded-md border border-border bg-secondary/50 px-4 py-3"
              style={{ borderLeft: `3px solid var(--sev-${s.severity >= 0.85 ? "critical" : s.severity >= 0.7 ? "high" : "moderate"})` }}
            >
              <div className="flex flex-wrap items-baseline justify-between gap-2">
                <p className="font-mono text-sm text-foreground">{s.name}</p>
                <span className="font-mono text-[10px] tracking-[0.14em] text-muted-foreground">
                  sev {s.severity.toFixed(2)}
                </span>
              </div>
              <p className="mt-1 font-mono text-[11px] text-muted-foreground">
                {s.organ} · {s.signal_type} — expect: {s.expect}
              </p>
              <p className="sr-only">step {i + 1} of {STEPS.length}</p>
            </li>
          ))}
        </ol>

        <div className="mt-6">
          <PhosphorButton onClick={runReplay} disabled={running}>
            <Play className="size-4" aria-hidden="true" />
            {running ? "Replaying…" : "Run campaign replay"}
          </PhosphorButton>
        </div>

        {log.length ? (
          <div className="mt-6 max-h-64 space-y-1 overflow-y-auto rounded-md border border-border bg-panel p-4 font-mono text-xs ph-scroller" aria-live="polite">
            {log.map((l, i) => (
              <p
                key={i}
                className={
                  l.kind === "error"
                    ? "text-sev-critical"
                    : l.kind === "hold"
                      ? "text-sev-moderate"
                      : l.kind === "signed" || l.kind === "plan"
                        ? "text-phosphor"
                        : "text-muted-foreground"
                }
              >
                {l.text}
              </p>
            ))}
          </div>
        ) : null}

        {error ? (
          <div className="mt-6">
            <BackendNotice detail={error} onRetry={refreshState} />
          </div>
        ) : null}
      </PhosphorPanel>

      <aside className="space-y-6">
        {/* fused campaign */}
        <PhosphorPanel className="p-6">
          <div className="flex items-center justify-between">
            <Kicker>FUSED CAMPAIGN VIEW</Kicker>
            <button
              type="button"
              onClick={refreshState}
              aria-label="Refresh campaign state"
              className="font-mono text-xs text-muted-foreground hover:text-phosphor"
            >
              ↻
            </button>
          </div>
          {top ? (
            <div className="mt-4 grid gap-3">
              <StatTile label="campaign" value={top.campaign_id ?? "—"} valueClass="text-sm" hint={`${top.size ?? "?"} events fused`} />
              <StatTile label="severity max" value={typeof top.severity_max === "number" ? top.severity_max.toFixed(3) : "—"} />
            </div>
          ) : (
            <p className="mt-3 text-sm text-muted-foreground">
              No fused campaign in the window yet — run the replay.
            </p>
          )}
          <div className="mt-4 grid grid-cols-2 gap-3">
            <StatTile
              label="unverified held"
              value={state?.fortress?.unverified_held ?? 0}
              hint="forged probes, kept as evidence"
            />
            <StatTile
              label="replay dropped"
              value={state?.fortress?.replay_dropped ?? 0}
              hint="same id inside 10 min is refused"
            />
          </div>
        </PhosphorPanel>

        <PhosphorPanel className="p-6">
          <Kicker>WHY THE FORGE MATTERS</Kicker>
          <div className="mt-3 space-y-3 text-sm text-muted-foreground">
            <p className="flex gap-2">
              <ShieldX className="mt-0.5 size-4 shrink-0 text-sev-moderate" aria-hidden="true" />
              Unsigned telemetry stays visible as evidence but can never steer the
              AI path or back a disruptive action — the orchestration refuses with
              HELD_UNVERIFIED_EVIDENCE.
            </p>
            <p className="flex gap-2">
              <ShieldCheck className="mt-0.5 size-4 shrink-0 text-phosphor" aria-hidden="true" />
              Signed telemetry traverses the same public endpoint and is verified
              by HMAC — only then may the Governor dispose and the dry-run
              executor act.
            </p>
          </div>
        </PhosphorPanel>
      </aside>
    </div>
  );
}
