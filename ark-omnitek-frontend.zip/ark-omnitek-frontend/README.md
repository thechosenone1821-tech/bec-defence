# ARK OMNITEK — Phosphor Console Frontend

A complete Next.js 16 frontend implementing the **Ark Omnitek Phosphor** design
system with a **Liquid Glass** primary mode switcher and a **3D Curved
Carousel** subapplication launcher. All seven subapplications are real,
functional destinations — no placeholders.

## Quick start

```bash
# 1. install dependencies (bun or npm)
bun install        # or: npm install

# 2. configure environment
cp .env.example .env
#    edit .env and point CITIZEN_API_URL / SPINE_BUS_URL /
#    NEXT_PUBLIC_SPINE_WS_URL at your backend services

# 3. create the local SQLite database
bun run db:push    # or: npx prisma db push

# 4. run in development
bun run dev        # or: npm run dev  ->  http://localhost:3000

# production build
bun run build
bun run start
```

## Navigation model

Primary Mode -> Subapplication -> Application

- **Liquid Glass mode switcher** (Consumer / Organization) — persists across
  navigation via URL search params + Zustand store, no full page reloads.
- **3D Curved Carousel** — swaps its contents when the mode changes.
- Every carousel card opens a real application route. You can switch between
  subapplications directly from the console header without returning to the
  home page.

| Mode | Subapplications | Route |
| --- | --- | --- |
| Consumer | MAYA | `/console/maya` |
| Consumer | VIGIL | `/console/vigil` |
| Consumer | Citizen Spine | `/console/citizen-spine` |
| Consumer | Message Guard | `/console/message-guard` |
| Organization | Rings | `/console/rings` |
| Organization | Red Team | `/console/red-team` |
| Organization | Governance | `/console/governance` |

## Backend integration points

All backend traffic is same-origin through Next.js API routes, which forward
to the configurable URLs in `.env`:

| Frontend route | Forwards to | Env var |
| --- | --- | --- |
| `/api/gateway/citizen/*` | citizen defence service | `CITIZEN_API_URL` |
| `/api/gateway/spine/*` | spine telemetry bus | `SPINE_BUS_URL` |
| `/api/gateway/spine-signed` | signs + ingests events | `SPINE_BUS_URL`, `SPINE_BUS_KEY` |
| `/api/gateway/status` | aggregated backend health | `CITIZEN_API_URL`, `SPINE_BUS_URL` |
| browser telemetry stream | live feed WebSocket | `NEXT_PUBLIC_SPINE_WS_URL` |

To connect your own backend, just set the env vars — no frontend code changes
are required. All variables have working localhost defaults.

## Where things live

```
src/
├── app/
│   ├── page.tsx                  # home: mode switcher + 3D carousel
│   ├── console/<app>/page.tsx    # the 7 subapplication pages
│   └── api/gateway/...           # backend proxy routes (edit URLs here only via .env)
├── components/
│   ├── shell/                    # console-shell, console-header,
│   │                             # mode-switcher (Liquid Glass),
│   │                             # curved-carousel (3D launcher)
│   ├── phosphor/primitives.tsx   # Ark Omnitek Phosphor design primitives
│   ├── features/                 # the 7 real subapplication implementations
│   └── ui/                       # shadcn/ui component library
├── lib/
│   ├── apps.ts                   # subapplication registry (names, routes, icons)
│   ├── mode-store.ts             # Zustand store for Consumer/Organization mode
│   └── gateway.ts                # typed gateway client used by all features
└── hooks/
    └── use-spine-feed.ts         # WebSocket telemetry feed hook
```

## Tech stack

Next.js 16 (App Router, standalone output) · React 19 · TypeScript ·
Tailwind CSS 4 · shadcn/ui · framer-motion · Zustand · Prisma (SQLite) ·
lucide-react
